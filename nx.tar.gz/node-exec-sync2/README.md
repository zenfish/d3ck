
<h4>Small Changes</h4>

A couple of very minor changes; first, no longer throw an exception if
command executed writes to stderr, and second, instead of returning a
string containing stdout, return an object that returns foo.stdout and
foo.stderr instead.


# node-exec-sync2
Execute shell commands synchronously.

## How does it work?
No special voodoo here. Just the usual "pipe to file, read file" you might have seen before and a somewhat cleaner code.

## Installation
```bash
npm install exec-sync2
```

## Usage
```javascript
var execSync = require('exec-sync2');
var result = execSync('your shell cmd');
```
